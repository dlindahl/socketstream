TODO
====

List of minor tasks to be done soon or already in progress:

* Improve generated 'new project' code
* Clean up API code - get rid of url_lib
* Fix errors generated in Firefox when server connection is dropped (does not affect reconnect) 
* Refactor coffee compile so we don't repeat ourselves
* Can we easily add gzip compression to static assets?
